#!/bin/bash
# Libertí importer — SERVER dry-run (READ-ONLY against the live DB).
# Creates venv on first run, then prints the plan without writing anything.
set -u
cd "$(dirname "$0")"          # bundle dir = /home/manouka/web/libertidance.com/import-bundle

LOG=dryrun-out.txt
exec > >(tee -a "$LOG") 2>&1
echo "=== DRY RUN start: $(date -u '+%Y-%m-%d %H:%M:%S UTC') ==="

# 1. dependencies (venv; falls back to --user pip if venv module is unavailable)
if [ ! -x .venv/bin/python ]; then
    echo "creating venv..."
    python3 -m venv .venv 2>&1 || echo "venv failed — will try pip --user"
fi
if [ -x .venv/bin/python ]; then
    PY=.venv/bin/python
    [ -x .venv/bin/pip ] || .venv/bin/python -m ensurepip --upgrade >/dev/null 2>&1
    .venv/bin/pip install -q -r requirements.txt 2>&1 | tail -1 || true
else
    PY=python3
    pip3 install --user -q pymysql python-dotenv || {
        echo "ERROR: could not install pymysql"; exit 1; }
    PY="python3"
fi

# 2. dry-run (read-only enforced in code AND by SET SESSION TRANSACTION READ ONLY)
"$PY" importer.py products.batch1.csv --dry-run --images images
RC=$?
echo "=== DRY RUN end (exit $RC): $(date -u '+%Y-%m-%d %H:%M:%S UTC') ==="
echo "IMPORTANT: review every plan line in $LOG. Nothing has been written."
